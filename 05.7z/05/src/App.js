import './App.css';
import RandomNumber from './components/RandomNumber'
import RandomWord from './components/randomPredlo.js'

function App() {
  //<RandomNumber max={10}/>
  return (
    <div className="App">
      
      
      <RandomWord maxWord={1}/>
      <RandomWord maxWord={20}/>
      <RandomWord maxWord={40}/>
      <RandomWord maxWord={50}/>
      <RandomWord maxWord={60}/>
      <RandomWord maxWord={70}/>
    </div>
  )
}

export default App;
