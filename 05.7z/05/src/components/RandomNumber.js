import{ useState } from 'react'
import {generateRandomNumber} from '../utilit/RandomJS.js'



function RandomNumber({max}){
    
    const [randomNum,setRandomNum] = useState(generateRandomNumber(max))
    
    const changeRandomNum = () => {
        setRandomNum(generateRandomNumber(max))
    }

    return(
        <div>
            <h1>{randomNum}</h1>
            <button onClick={changeRandomNum}>Generate random number</button>
        </div>
    )
}

export default RandomNumber;