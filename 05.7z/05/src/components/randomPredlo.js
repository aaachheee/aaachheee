

function RandomWord(props = 10){
    const words = ["q","w","e","r","t","y","u","i","o","p","a","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m",]
    const space = [" "]
    const predloj = [" "]
    
    
    
    for(let i =0;i<props.maxWord;i++){
        for(let k = 0;k<20;k++){
            //words[Math.random() * words.length]
            
            predloj.push(words[k = Math.floor(Math.random() * words.length)])

            
        }
        predloj.push(space[0])
        
            
    } 
    
    return(
        <div>
            <p>{predloj}</p>
        </div>
    )
}

export default RandomWord;