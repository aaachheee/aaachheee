function generateRandomNumber(a = 100){
    return Math.floor(Math.random() * a)
}

export {generateRandomNumber}
